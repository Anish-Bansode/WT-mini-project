
document.addEventListener("DOMContentLoaded", function() {
    loadTasks();
});

function addTask() {
    var taskInput = document.getElementById("taskInput");
    var taskList = document.getElementById("taskList");
    
    if (taskInput.value === "") {
        alert("Please enter a task!");
        return;
    }

    var li = document.createElement("li");
    li.textContent = taskInput.value;
    li.onclick = function() {
        this.classList.toggle("completed");
        saveTasks();
    };

    var removeButton = document.createElement("button");
    removeButton.textContent = "Remove";
    removeButton.className = "remove-button";
    removeButton.onclick = function(event) {
        event.stopPropagation();
        taskList.removeChild(li);
        saveTasks();
    };

    li.appendChild(removeButton);
    taskList.appendChild(li);
    taskInput.value = "";

    saveTasks();
}

function saveTasks() {
    var taskList = document.getElementById("taskList");
    localStorage.setItem("tasks", taskList.innerHTML);
}

function loadTasks() {
    var taskList = document.getElementById("taskList");
    taskList.innerHTML = localStorage.getItem("tasks") || "";

    var removeButtons = document.querySelectorAll(".remove-button");
    removeButtons.forEach(function(button) {
        button.onclick = function(event) {
            event.stopPropagation(); 
            var listItem = button.parentElement;
            taskList.removeChild(listItem);
            saveTasks();
        };
    });
}

function assignProject() {
    const projectNameInput = document.getElementById('projectName');
    const projectManagerSelect = document.getElementById('projectManager');

    const projectName = projectNameInput.value;
    const projectManager = projectManagerSelect.value;

    if (projectName.trim() === '' || projectManager.trim() === '') {
        alert('Please enter project name and select project manager.');
        return;
    }

    const newProject = { name: projectName, manager: projectManager, progress: 0 };
    projects.push(newProject);


    projectNameInput.value = '';
    projectManagerSelect.selectedIndex = 0;

    displayProjects();
}

let projects = [
    { name: "Project 1", manager: "Sanjeev Gupta", progress: 60 },
    { name: "Project 2", manager: "Raju Singh", progress: 80 },
    { name: "Project 3", manager: "Amit Kumar", progress: 10 },
    { name: "Project 4", manager: "Rajverdhan Patil", progress: 40 }
];

function updateProjectProgress() {
    const projectElements = document.querySelectorAll('.project');
    projectElements.forEach((projectElement, index) => {
        const progressElement = projectElement.querySelector('.progress');

        // fetching progress from an API
        fetch(`https://api.example.com/project/${projects[index].name}/progress`)
            .then(response => response.json())
            .then(data => {
                // Update progress
                projects[index].progress = data.progress;
                progressElement.style.width = `${data.progress}%`;
                progressElement.textContent = `${data.progress}%`;
            })
            .catch(error => {
                console.error('Error fetching progress:', error);
            });
    });
}

// Display
function displayProjects() {
    const projectsContainer = document.querySelector('.projects');
    projectsContainer.innerHTML = '';

    projects.forEach(project => {
        const projectDiv = document.createElement('div');
        projectDiv.classList.add('project');

        const projectName = document.createElement('h4');
        projectName.textContent = project.name;

        const managerName = document.createElement('p');
        managerName.textContent = `Project Manager: ${project.manager}`;

        const progressBar = document.createElement('div');
        progressBar.classList.add('progress-bar');
        const progress = document.createElement('div');
        progress.classList.add('progress');
        progress.style.width = `${project.progress}%`;
        progress.textContent = `${project.progress}%`;

        progressBar.appendChild(progress);

        projectDiv.appendChild(projectName);
        projectDiv.appendChild(managerName);
        projectDiv.appendChild(progressBar);

        projectsContainer.appendChild(projectDiv);
    });
}
displayProjects();
updateProjectProgress();
    