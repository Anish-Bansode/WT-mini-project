document.addEventListener("DOMContentLoaded", function() {
  const loginForm = document.getElementById("loginForm");

  loginForm.addEventListener("submit", function(event) {
      event.preventDefault();

      const username = document.getElementById("IDInput").value;
      const password = document.getElementById("PassInput").value;

      fetch("settings.json")
          .then(response => response.json())
          .then(data => {
              const users = data.users;

              
              const user = users.find(u => u.username === username && u.password === password);
              if (user) {
                  
                  localStorage.setItem("currentUser", JSON.stringify(user));
                
                  window.location.href = user.redirect;
              } else {
                  alert("Invalid username or password");
              }
          })
          .catch(error => console.error("Error:", error));
  });
});
